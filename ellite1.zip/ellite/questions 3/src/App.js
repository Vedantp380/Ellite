import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import NavComponent from './Component/navComponent';
import EmpComponent from './Component/employeeData';


function App() {
  
  return (
    <div>
        <Router>    
              <NavComponent/>
              <EmpComponent/>
        </Router>
    </div>
  );
}

export default App;
