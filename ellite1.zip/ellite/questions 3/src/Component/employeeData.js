import React, { Component } from 'react';

class EmpComponent extends Component {
	documentData;
    constructor(props) {
		let employees = JSON.parse(localStorage.getItem('document'));
        super(props)
		this.handleChange = this.handleChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.state = {
			employees:[employees],
			name: '',
            gender: '',
			age: '',
			designation:'',
			department:'',
			join_date:''
        }
	}
	
	handleChange = (e)=> {
		this.setState({[e.target.name]:e.target.value});
	}
	// on form submit...
	handleFormSubmit(e) {
		e.preventDefault()
	   localStorage.setItem('document',JSON.stringify(this.state));
	}
	componentDidMount() {
		this.documentData = JSON.parse(localStorage.getItem('document'));
		console.log(this.documentData);
		if (localStorage.getItem('document')) {
			this.setState({
			   name: this.documentData.name,
			   gender: this.documentData.gender,
			   age: this.documentData.age,
			   designation: this.documentData.designation,
			   department: this.documentData.department,
			   join_date: this.documentData.join_date
		})
	} else {
		this.setState({
			name: '',
            gender: '',
			age: '',
			designation:'',
			department:'',
			join_date:''
		})
	}
	}
	
    render() {
		var employeeData = this.state.employees;
        return (

            <div className="container-fluid">
		<div className="row">
			<div className="col-12">
				<div className="question-dashboard">
					<div className="card mt-4 mb-3 mb-md-4">
						<div className="card-body p-3">
							<h5 className="text-secondary mb-2">Available: <span
									className="font-weight-bold ml-1 text-dark">{localStorage.length}</span></h5>
							<h5 className="text-secondary">Total: <span className="font-weight-bold ml-1 text-dark">{localStorage.length}</span>
							</h5>
							​
							<button className="btn btn-primary mt-4" data-toggle="modal" data-target="#addEmployeeModal">
								<i className="fa fa-plus"></i>&nbsp; Add Employee</button>
						</div>
					</div>
					​
					<div className="table-responsive mt-3 mt-md-4 mb-2">
						<table className="table table-bordered">
							<thead>
								<tr>
									<th>Name</th>
									<th>Department</th>
									<th>Available</th>
									<th>View Details</th>
								</tr>
							</thead>
							<tbody>
							{employeeData && employeeData.map((data) => {
									return (<tr>
									
									<td>{data.name}</td>
									<td>{data.department}</td>
									<td><input type="checkbox" id="" name="availability" value="true" checked/></td>
									<td><button type="button" class="btn btn-outline-info btn-sm" data-toggle="modal" data-target="#addEmployeeModal">
											<i class="fa fa-edit"></i>&nbsp; Edit
                    </button>
                    <button type="button" class="btn btn-outline-danger btn-sm">
											<i class="fa fa-trash"></i>&nbsp; Delete
										</button></td>
									</tr>);
								})}
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<div id="addPopUp"></div>

		<div className="modal fade" id="addEmployeeModal" tabindex="-1" role="dialog" aria-labelledby="addEmployeeModal"
	aria-hidden="true">
	<div className="modal-dialog modal-dialog-centered" role="document">
		<div className="modal-content">
			<div className="modal-header pt-3 pb-2">
				<h5 className="modal-title" id="exampleModalCenterTitle">Add Employee</h5>
				<button type="button" className="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div className="modal-body">
				<form onSubmit={this.handleFormSubmit}>
					<div className="form-row ">
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Name</label>
							<input type="text" name="name" className="form-control" value={this.state.name} onChange={this.handleChange} id="" placeholder="Enter" required/>
						</div>
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Gender</label>
							<select className="form-control" name="gender" value={this.state.gender} onChange={this.handleChange} id="exampleFormControlSelect1">
								<option >Select</option>
								<option value="male" >Male</option>
								<option value="female">Female</option>
							</select>
						</div>
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Age</label>
							<input type="text" className="form-control" name="age" id="" value={this.state.age} onChange={this.handleChange} placeholder="Enter"/>
						</div>
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Designation</label>
							<input type="text" className="form-control" id="" value={this.state.designation} onChange={this.handleChange} name="designation" placeholder="Enter"/>
						</div>
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Department</label>
							<input type="text" className="form-control" id="" name="department" value={this.state.department} onChange={this.handleChange} placeholder="Enter"/>
						</div>
						<div className="form-group col-md-6">
							<label for="" className="mb-1">Joining Date</label>
							<input type="date" className="form-control" name="join_date" id="" value={this.state.join_date} onChange={this.handleChange} placeholder=""/>
						</div>
					</div>
					<div className="modal-footer">
						<button type="button" className="btn btn-outline-danger btn-sm" data-dismiss="modal">Cancel</button>
						<button type="submit" className="btn btn-success btn-sm">Save</button>
					</div>
				</form>
				
			</div>
			
		</div>
	</div>
</div>
	</div>
	
        )
    }
}

export default EmpComponent